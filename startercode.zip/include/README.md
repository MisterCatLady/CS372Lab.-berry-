---
include/README.md
---

Use this folder for include files used by multiple applications.


